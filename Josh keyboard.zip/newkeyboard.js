Const Keyboard ={
    elements:{
        main:null
        keycontainer:null
            keys:[]
        }
            
        
            
    }
    eventHandlers:{
        oninput:null
        onclick:null
    };

};